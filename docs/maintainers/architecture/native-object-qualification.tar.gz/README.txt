Native object storage qualification, PR 1069
Task 2 3ac60f34, merged ac2db0dc, PR e68ab200, candidate c51cc58f.
Raw Go benchmark output, with repeated test status lines omitted.
Go 1.27.4 darwin/arm64, Apple M2 Max. Each file preserves sample order.
matrix: 10 balanced interleaved 200 ms samples, 114 rows per revision.
confirm: 20 alternating one-second samples, 7 rows per revision.
shape: 20 alternating one-second samples of VM shape build and overwrite.
benchstat matrix-task2.txt matrix-merged.txt matrix-pr.txt matrix-final.txt
benchstat matrix-merged.txt matrix-final.txt
benchstat confirm-merged.txt confirm-final.txt

Pilots used the same fixtures and host. screen: index cutoffs 128 (pr),
32, 16, 8; larger bounded reservations use the tracked Go map via the group.
maps: cut8 uses the group, direct keeps a reserved Go map on the native
handle. exact reserves the VM live count plus one, the others double it.
linear: 16 filtered contiguous slots without a fingerprint index.
dispatch: concrete calls the known FastObject.Get on dictionary cache
fallback; resolvedexact specializes runtime.String; both combines them.
writing: setter branch order and helper placement; final is aacb7496.
slotnative: final is aacb7496; finalslot reuses the named shape slot.
The last VM-only edit affected the VM and FQL binaries. Every VM and FQL
row was rerun in the final qualification. SHA-256 verified that the native
runtime and codec binaries were identical to their earlier measured builds.
matrix.md gives all comparison medians and pairwise timing p-values.
See the investigation for the production layout and historical adapters.

Review qualification of 76aecf6a (identical production in 8710cba0).
Use the historical fixture adapters described in native-object-inspection-cost.md.
Use the corrected object_operations_bench_test.go on all four revisions.
Omit only the debugger preflight on Task 2, which predates that method.
For the same-VM comparison add the candidate shape-read fixture to 8a35deb0.
Modules, pkg production files, GOARCH and Go version match the named revisions.
Build each binary with GOWORK=off GOFLAGS=-mod=readonly GOTOOLCHAIN=local
CGO_ENABLED=1 GOMAXPROCS=2 go test -p=2 -c -o OUTPUT ./pkg/runtime
or ./test/benchmarks for the FQL rows. Run single rows serially, for example:
./candidate-fql.test -test.run='^$' -test.bench='^BenchmarkObjectShapeReads_None$/^dynamic$' -test.benchmem -test.cpu=1 -test.benchtime=1s -test.count=1
./candidate-fql.test -test.run='^$' -test.bench='^BenchmarkObjectDictionaryReads_None$/^miss$' -test.benchmem -test.cpu=1 -test.benchtime=1s -test.count=1
./candidate-native.test -test.run='^$' -test.bench='^BenchmarkObjectOperations$/^128$/^insert_remove$' -test.benchmem -test.cpu=1 -test.benchtime=200ms -test.count=1
The order TSVs identify each row, revision and round. Raw output omits repeated headers and PASS.
benchstat dictionary-merged.txt dictionary-candidate.txt
benchstat dictionary-repeat-merged.txt dictionary-repeat-candidate.txt
benchstat shape-before.txt shape-candidate.txt
benchstat mutation-task2.txt mutation-merged.txt mutation-pr.txt mutation-candidate.txt
benchstat mutation-merged.txt mutation-candidate.txt
